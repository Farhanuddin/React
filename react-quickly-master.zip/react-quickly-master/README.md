# React Quickly Source Code

Source code for *React Quickly: Painless Web Apps with React, JSX, Redux, and GraphQL 📕* [Manning, 2017]. More information at
the [website](http://reactquickly.co) or [Manning Publications](https://www.manning.com/books/react-quickly?a_aid=a&a_bid=5064a2d3).

Available NOW in major book stores and at [Manning](https://www.manning.com/books/react-quickly?a_aid=a&a_bid=5064a2d3).
