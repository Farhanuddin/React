ReactDOM.render(
  <div>
    <SliderValue />
    <SliderButtons/>
  </div>,
  document.getElementById('content')
)
