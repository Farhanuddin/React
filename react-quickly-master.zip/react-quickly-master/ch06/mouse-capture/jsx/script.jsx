ReactDOM.render(
  <Mouse />,
  document.getElementById('content')
)
