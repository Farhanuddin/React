module.exports = function() {
  return Math.random().toString(36).slice(-8)
}
