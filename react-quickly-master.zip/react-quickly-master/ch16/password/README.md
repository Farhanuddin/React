To run:

```
$ npm build-watch
$ npm build
```

To test:

```
$ npm test
$ npm test-watch
```
