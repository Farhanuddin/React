ReactDOM.render(
  <Clock />,
  document.getElementById('content')
)
