ReactDOM.render(
  <Content />,
  document.getElementById('content')
)