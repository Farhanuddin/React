ReactDOM.render(
  <div>
    <Content />
  </div>,
  document.getElementById('content')
)
